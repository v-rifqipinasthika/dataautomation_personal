function(element, input) {
    document.getElementById('txt_daterange_start').value = input;
    document.getElementById('txt_daterange_end').value = input;
    return "done"
}